import { Component, OnInit } from '@angular/core';
import { MotorService } from '../motor.service';
import { Motor } from '../model/motor';
import { Router } from '@angular/router';

@Component({
  selector: 'app-motor-create',
  templateUrl: './motor-create.component.html',
  styleUrls: ['./motor-create.component.css']
})
export class MotorCreateComponent implements OnInit {

  motor: Motor = new Motor();

  constructor(private motorService: MotorService,
              private router: Router) { }

  ngOnInit(): void {
  }
  save(){
    console.log(this.motor);
    this.motorService.createMotor(this.motor).subscribe(
      data => this.router.navigate(['/list']) //luego ir a list para ver si se ha creado el motor
    )
  }

}
