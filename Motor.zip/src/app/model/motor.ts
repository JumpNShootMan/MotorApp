export class Motor {
    idMotor: number;
    modelo: string;
    marca: string;
    precio: number;
}
