import { Motor } from './motor';

describe('Motor', () => {
  it('should create an instance', () => {
    expect(new Motor()).toBeTruthy();
  });
});
