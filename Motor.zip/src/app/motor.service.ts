import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http'; //definir a mano
import {Motor} from './model/motor'; //definir a mano
import {map} from 'rxjs/operators'; //definir a mano
import {Observable} from 'rxjs'; //definir a mano

@Injectable({
  providedIn: 'root'
})
export class MotorService {
//definir a mano
private urlBase = 'http://localhost:8080/api';
private httpHeaders = new HttpHeaders({'Content-type' : 'application/json'}); //definir a mano
//inyectar http, también importarlo en app.module.ts
constructor(private http: HttpClient) { }

createMotor(motor: Object) : Observable<Object>{ //para crear en create-product
  return this.http.post(this.urlBase+'/motor',motor, {headers:this.httpHeaders}); //enviando el producto al REST de STS
}

getMotorList(): Observable<any>{ //Para llamar a la lista de productos en product-list.components.ts
  console.log('Llamando a REST: '+ this.urlBase + '/motores');
  return this.http.get(this.urlBase+'/motores').pipe( //llamado al REST de STS!
    map(response => response as Motor[])
    );
  }

getMotorListPrecios(v1,v2): Observable<any>{ //Para llamar a la lista de productos en product-list.components.ts
    console.log('Llamando a REST: '+ this.urlBase + '/motores'+'/'+v1+'/'+v2);
    return this.http.get(this.urlBase+'/motores'+'/'+v1+'/'+v2).pipe( //llamado al REST de STS!
      map(response => response as Motor[])
      );
    }
}
