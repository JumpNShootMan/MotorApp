import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Motor } from '../model/motor';
import { MotorService } from '../motor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-motor-pricelist',
  templateUrl: './motor-pricelist.component.html',
  styleUrls: ['./motor-pricelist.component.css']
})
export class MotorPricelistComponent implements OnInit {

  motors: Observable<Motor> //se usa en html ngFor let p of products para acceder p.Propiedades como un query

  constructor(private motorService: MotorService) { }
  ngOnInit(): void {
    this.reloadData()
  }

  reloadData(){
    console.log("Reload!!!")
    this.motorService.getMotorListPrecios(1000,4000).subscribe(motors => this.motors = motors);
  }
}
