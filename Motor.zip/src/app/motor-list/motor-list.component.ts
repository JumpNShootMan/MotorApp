import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Motor } from '../model/motor';
import { MotorService } from '../motor.service';

@Component({
  selector: 'app-motor-list',
  templateUrl: './motor-list.component.html',
  styleUrls: ['./motor-list.component.css']
})
export class MotorListComponent implements OnInit {
  //manual
  motors: Observable<Motor> //se usa en html ngFor let p of products para acceder p.Propiedades como un query

  constructor(private motorService: MotorService) { }

  ngOnInit(): void {
    this.reloadData()
  }

  //Auto cargado de data creado
  reloadData(){
    console.log("Reload!!!")
    this.motorService.getMotorList().subscribe(motors => this.motors = motors);
  }

}
