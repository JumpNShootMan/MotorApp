import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MotorListComponent } from './motor-list/motor-list.component';
import { MotorCreateComponent } from './motor-create/motor-create.component';
import { MotorPricelistComponent } from './motor-pricelist/motor-pricelist.component';
//Para llamar a REST...
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
//

@NgModule({
  declarations: [
    AppComponent,
    MotorListComponent,
    MotorCreateComponent,
    MotorPricelistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
